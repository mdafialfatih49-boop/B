package com.beetitan.registry;

import com.beetitan.BeeTitanMod;
import com.beetitan.entity.BeeTitanEntity;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final EntityType<BeeTitanEntity> BEE_TITAN = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(BeeTitanMod.MOD_ID, "bee_titan"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, BeeTitanEntity::new)
                    .dimensions(EntityDimensions.fixed(2.4f, 5.0f))
                    .trackRangeBlocks(96)
                    .build());

    public static final Item BEE_TITAN_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(BeeTitanMod.MOD_ID, "bee_titan_spawn_egg"),
            new SpawnEggItem(BEE_TITAN, 0xF2B90F, 0xE07B00, new FabricItemSettings()));

    private ModEntities() {}

    public static void register() {
        FabricDefaultAttributeRegistry.register(BEE_TITAN, BeeTitanEntity.createAttributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(BEE_TITAN_SPAWN_EGG));
    }
}
