package com.beetitan.client;

import com.beetitan.entity.BeeTitanEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class BeeTitanRenderer extends GeoEntityRenderer<BeeTitanEntity> {
    public BeeTitanRenderer(EntityRendererFactory.Context context) {
        super(context, new BeeTitanModel());
        this.shadowRadius = 1.8f;
    }
}
