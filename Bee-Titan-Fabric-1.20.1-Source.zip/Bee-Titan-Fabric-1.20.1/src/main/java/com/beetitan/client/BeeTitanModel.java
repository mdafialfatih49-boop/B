package com.beetitan.client;

import com.beetitan.BeeTitanMod;
import com.beetitan.entity.BeeTitanEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

public class BeeTitanModel extends GeoModel<BeeTitanEntity> {
    private static final Identifier MODEL = new Identifier(BeeTitanMod.MOD_ID, "geo/bee_titan.geo.json");
    private static final Identifier TEXTURE = new Identifier(BeeTitanMod.MOD_ID, "textures/entity/bee_titan.png");
    private static final Identifier ANIMATION = new Identifier(BeeTitanMod.MOD_ID, "animations/bee_titan.animation.json");

    @Override
    public Identifier getModelResource(BeeTitanEntity animatable) {
        return MODEL;
    }

    @Override
    public Identifier getTextureResource(BeeTitanEntity animatable) {
        return TEXTURE;
    }

    @Override
    public Identifier getAnimationResource(BeeTitanEntity animatable) {
        return ANIMATION;
    }

    /** Kepala ikut menoleh ke arah target / pemain (ditambahkan di atas animasi). */
    @Override
    public void setCustomAnimations(BeeTitanEntity animatable, long instanceId, AnimationState<BeeTitanEntity> animationState) {
        super.setCustomAnimations(animatable, instanceId, animationState);

        CoreGeoBone head = getAnimationProcessor().getBone("head");
        if (head != null) {
            EntityModelData data = animationState.getData(DataTickets.ENTITY_MODEL_DATA);
            head.setRotX(head.getRotX() + data.headPitch() * MathHelper.RADIANS_PER_DEGREE);
            head.setRotY(head.getRotY() + data.netHeadYaw() * MathHelper.RADIANS_PER_DEGREE);
        }
    }
}
