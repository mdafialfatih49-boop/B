package com.beetitan.entity;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Bee Titan - golem lebah raksasa.
 *
 * Ability:
 *  - PUNCH   : pukulan kiri/kanan bergantian (knockback + slowness)
 *  - SLAM    : Honey Quake, hantaman tanah AoE
 *  - SPIN    : Pollen Whirlwind, putaran 2x yang melempar musuh
 *  - DASH    : Royal Charge, menerjang lurus lalu menabrak
 *  - VOLLEY  : Stinger Volley, 3 gelombang panah racun
 *  - SUMMON  : memanggil koloni lebah marah
 *  - ROAR    : fase enrage di HP 50% (shockwave, buff, lebah)
 *  - HEAL    : Royal Jelly, heal + absorption + resistance di HP 35%
 */
public class BeeTitanEntity extends HostileEntity implements GeoEntity {

    // ====== nama animasi (harus sama dengan bee_titan.animation.json) ======
    private static final String ANIM_PREFIX = "animation.bee_titan.";
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop(ANIM_PREFIX + "idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop(ANIM_PREFIX + "walk");
    private static final RawAnimation RUN = RawAnimation.begin().thenLoop(ANIM_PREFIX + "run");

    private static final String BEE_TAG = "titan_bee";

    public enum Ability {
        NONE(null, 0, 0),
        PUNCH(null, 22, 14),          // animasi dipilih kiri/kanan
        SLAM("slam", 40, 160),
        SPIN("spin", 50, 240),
        DASH("dash", 30, 200),
        VOLLEY("volley", 40, 180),
        SUMMON("summon", 45, 420),
        ROAR("roar", 50, 0),
        HEAL("heal", 40, 1200);

        final String anim;
        final int duration;
        final int cooldown;

        Ability(String anim, int duration, int cooldown) {
            this.anim = anim;
            this.duration = duration;
            this.cooldown = cooldown;
        }
    }

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("entity.beetitan.bee_titan"), BossBar.Color.YELLOW, BossBar.Style.NOTCHED_10);

    private Ability active = Ability.NONE;
    private int abilityTick = 0;
    private final int[] cooldowns = new int[Ability.values().length];
    private boolean enraged = false;
    private boolean nextPunchLeft = false;
    private Vec3d dashDir = Vec3d.ZERO;
    private final Set<UUID> dashHit = new HashSet<>();

    public BeeTitanEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 300;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
                .add(EntityAttributes.GENERIC_ATTACK_KNOCKBACK, 1.5)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.9)
                .add(EntityAttributes.GENERIC_ARMOR, 10.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    // =====================================================================
    //  AI
    // =====================================================================
    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new ChaseGoal(this));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 14.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Mengejar target. Berhenti saat sedang memakai ability yang mengunci gerakan. */
    static class ChaseGoal extends Goal {
        private final BeeTitanEntity titan;
        private int repath;

        ChaseGoal(BeeTitanEntity titan) {
            this.titan = titan;
            this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            LivingEntity t = titan.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean shouldContinue() {
            return canStart();
        }

        @Override
        public void start() {
            repath = 0;
        }

        @Override
        public void stop() {
            titan.getNavigation().stop();
            titan.setSprinting(false);
        }

        @Override
        public void tick() {
            LivingEntity t = titan.getTarget();
            if (t == null) return;
            titan.getLookControl().lookAt(t, 30.0f, 30.0f);

            if (titan.isRooted()) {
                titan.getNavigation().stop();
                titan.setSprinting(false);
                return;
            }
            if (titan.active == Ability.DASH) {
                titan.setSprinting(true);
                return;
            }

            double distSq = titan.squaredDistanceTo(t);
            boolean spinning = titan.active == Ability.SPIN;
            titan.setSprinting(!spinning && distSq > 100.0);

            if (distSq < 9.0 && !spinning) {
                titan.getNavigation().stop();
                return;
            }
            if (--repath <= 0) {
                repath = 6;
                double speed = spinning ? 0.6 : (distSq > 100.0 ? 1.35 : 1.0);
                titan.getNavigation().startMovingTo(t, speed);
            }
        }
    }

    boolean isRooted() {
        return active != Ability.NONE && active != Ability.SPIN && active != Ability.DASH;
    }

    // =====================================================================
    //  Tick utama / pemilihan ability
    // =====================================================================
    @Override
    protected void mobTick() {
        super.mobTick();
        bossBar.setPercent(getHealth() / getMaxHealth());

        for (int i = 0; i < cooldowns.length; i++) {
            if (cooldowns[i] > 0) cooldowns[i]--;
        }

        LivingEntity target = getTarget();
        if (active == Ability.NONE) {
            if (target != null && target.isAlive() && this.age % 4 == 0) {
                chooseAbility(target);
            }
        } else {
            tickAbility(target);
        }
    }

    private boolean ready(Ability a) {
        return cooldowns[a.ordinal()] <= 0;
    }

    private void chooseAbility(LivingEntity target) {
        double dist = Math.sqrt(squaredDistanceTo(target));
        boolean sees = canSee(target);
        float hp = getHealth() / getMaxHealth();

        if (!enraged && hp <= 0.5f) {
            startAbility(Ability.ROAR, target);
            return;
        }
        if (hp <= 0.35f && ready(Ability.HEAL)) {
            startAbility(Ability.HEAL, target);
            return;
        }

        List<Ability> pool = new ArrayList<>();
        if (dist <= 4.6 && ready(Ability.PUNCH)) {
            for (int i = 0; i < 4; i++) pool.add(Ability.PUNCH);
        }
        if (dist <= 7.0 && ready(Ability.SLAM)) {
            pool.add(Ability.SLAM);
            pool.add(Ability.SLAM);
        }
        if (dist <= 5.5 && ready(Ability.SPIN)) {
            pool.add(Ability.SPIN);
            if (enraged) pool.add(Ability.SPIN);
        }
        if (dist >= 7.0 && dist <= 26.0 && sees && ready(Ability.DASH)) {
            pool.add(Ability.DASH);
            pool.add(Ability.DASH);
        }
        if (dist >= 6.0 && dist <= 30.0 && sees && ready(Ability.VOLLEY)) {
            pool.add(Ability.VOLLEY);
            pool.add(Ability.VOLLEY);
        }
        if (dist <= 30.0 && ready(Ability.SUMMON) && countTitanBees() < 8) {
            pool.add(Ability.SUMMON);
        }
        if (pool.isEmpty()) return;

        startAbility(pool.get(this.random.nextInt(pool.size())), target);
    }

    private void startAbility(Ability ability, LivingEntity target) {
        this.active = ability;
        this.abilityTick = 0;
        this.dashHit.clear();
        this.cooldowns[ability.ordinal()] = ability.cooldown;
        getNavigation().stop();

        String anim;
        if (ability == Ability.PUNCH) {
            anim = nextPunchLeft ? "punch_left" : "punch_right";
            nextPunchLeft = !nextPunchLeft;
        } else {
            anim = ability.anim;
        }
        if (ability == Ability.ROAR) {
            this.enraged = true;
        }
        triggerAnim("action", anim);
    }

    private void tickAbility(LivingEntity target) {
        abilityTick++;
        final int t = abilityTick;

        switch (active) {
            case PUNCH -> {
                faceTarget(target, 30f);
                if (t == 10) doPunch();
            }
            case SLAM -> {
                faceTarget(target, 20f);
                if (t == 20) doSlam();
            }
            case SPIN -> doSpin(t, target);
            case DASH -> doDash(t, target);
            case VOLLEY -> {
                faceTarget(target, 25f);
                if (t == 20 || t == 26 || t == 32) doVolley(target);
            }
            case SUMMON -> {
                faceTarget(target, 25f);
                if (t == 25) {
                    summonBees(target, enraged ? 6 : 4);
                    playSound(SoundEvents.ENTITY_BEE_LOOP_AGGRESSIVE, 2.0f, 0.5f);
                }
            }
            case ROAR -> doRoar(t, target);
            case HEAL -> doHeal(t);
            default -> { }
        }

        if (t >= active.duration) {
            active = Ability.NONE;
            abilityTick = 0;
        }
    }

    // =====================================================================
    //  Implementasi tiap ability
    // =====================================================================
    private float attackDamage() {
        return (float) getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE) * (enraged ? 1.25f : 1.0f);
    }

    private boolean isValidVictim(LivingEntity e) {
        if (e == this || !e.isAlive()) return false;
        if (e instanceof BeeTitanEntity) return false;
        if (e.getCommandTags().contains(BEE_TAG)) return false;
        if (e instanceof PlayerEntity p && (p.isCreative() || p.isSpectator())) return false;
        return true;
    }

    private List<LivingEntity> victimsIn(Box box) {
        return getWorld().getEntitiesByClass(LivingEntity.class, box, this::isValidVictim);
    }

    private void hurt(LivingEntity e, float amount) {
        e.damage(getDamageSources().mobAttack(this), amount);
    }

    private void knock(LivingEntity e, double strength, double up) {
        e.takeKnockback(strength, getX() - e.getX(), getZ() - e.getZ());
        e.addVelocity(0.0, up, 0.0);
        e.velocityModified = true;
    }

    private void faceTarget(LivingEntity target, float maxStep) {
        if (target == null) return;
        double dx = target.getX() - getX();
        double dz = target.getZ() - getZ();
        turnTowards((float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f, maxStep);
    }

    private void turnTowards(float yaw, float maxStep) {
        float diff = MathHelper.wrapDegrees(yaw - getYaw());
        float newYaw = getYaw() + MathHelper.clamp(diff, -maxStep, maxStep);
        setYaw(newYaw);
        setBodyYaw(newYaw);
        setHeadYaw(newYaw);
    }

    private static final BlockStateParticleEffect HONEY_BITS =
            new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.HONEY_BLOCK.getDefaultState());

    // ---- PUNCH ----
    private void doPunch() {
        ServerWorld sw = (ServerWorld) getWorld();
        Vec3d look = Vec3d.fromPolar(0, getYaw());
        float dmg = attackDamage();
        playSound(SoundEvents.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.6f);

        for (LivingEntity e : victimsIn(getBoundingBox().expand(3.5, 0.5, 3.5))) {
            double dx = e.getX() - getX();
            double dz = e.getZ() - getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            double dot = dx * look.x + dz * look.z;
            if (dot <= 0.0 || dist > 5.2) continue;

            hurt(e, dmg);
            knock(e, 1.6, 0.45);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 0));
            sw.spawnParticles(HONEY_BITS, e.getX(), e.getBodyY(0.6), e.getZ(), 25, 0.4, 0.5, 0.4, 0.15);
        }
    }

    // ---- SLAM : Honey Quake ----
    private void doSlam() {
        ServerWorld sw = (ServerWorld) getWorld();
        Vec3d fwd = Vec3d.fromPolar(0, getYaw()).multiply(3.5);
        double cx = getX() + fwd.x;
        double cz = getZ() + fwd.z;
        double radius = enraged ? 9.0 : 7.0;
        float dmg = attackDamage() * 0.9f;

        playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 2.0f, 0.55f);
        playSound(SoundEvents.BLOCK_HONEY_BLOCK_BREAK, 2.0f, 0.5f);

        Box box = new Box(cx - radius, getY() - 2.0, cz - radius, cx + radius, getY() + 4.0, cz + radius);
        for (LivingEntity e : victimsIn(box)) {
            double d = Math.sqrt(e.squaredDistanceTo(cx, e.getY(), cz));
            if (d > radius) continue;
            float falloff = (float) (1.0 - (d / (radius + 3.0)));
            hurt(e, dmg * falloff);
            knock(e, 1.4, 0.65);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
        }

        for (int ring = 1; ring <= (int) radius; ring += 2) {
            int points = 10 + ring * 6;
            for (int i = 0; i < points; i++) {
                double a = (Math.PI * 2.0) * i / points;
                sw.spawnParticles(HONEY_BITS, cx + Math.cos(a) * ring, getY() + 0.2, cz + Math.sin(a) * ring,
                        2, 0.1, 0.1, 0.1, 0.25);
            }
        }
        sw.spawnParticles(ParticleTypes.FALLING_HONEY, cx, getY() + 3.0, cz, 80, radius * 0.4, 1.0, radius * 0.4, 0.0);
    }

    // ---- SPIN : Pollen Whirlwind ----
    private void doSpin(int t, LivingEntity target) {
        ServerWorld sw = (ServerWorld) getWorld();
        if (t >= 8 && t <= 44) {
            for (int k = 0; k < 4; k++) {
                double a = t * 0.9 + k * Math.PI / 2.0;
                sw.spawnParticles(ParticleTypes.SWEEP_ATTACK, getX() + Math.cos(a) * 4.0, getY() + 1.6,
                        getZ() + Math.sin(a) * 4.0, 1, 0, 0, 0, 0);
                sw.spawnParticles(ParticleTypes.WAX_ON, getX() + Math.cos(a) * 3.0, getY() + 2.4,
                        getZ() + Math.sin(a) * 3.0, 2, 0.2, 0.2, 0.2, 0.0);
            }
        }
        if (t >= 10 && t <= 44 && t % 5 == 0) {
            playSound(SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 2.0f, 0.5f);
            float dmg = attackDamage() * 0.5f;
            for (LivingEntity e : victimsIn(getBoundingBox().expand(4.2, 0.5, 4.2))) {
                if (squaredDistanceTo(e) > 6.5 * 6.5) continue;
                hurt(e, dmg);
                knock(e, 1.1, 0.35);
            }
        }
    }

    // ---- DASH : Royal Charge ----
    private void doDash(int t, LivingEntity target) {
        ServerWorld sw = (ServerWorld) getWorld();
        if (t < 10) {
            faceTarget(target, 35f);
            if (t == 1) playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 0.8f);
            return;
        }
        if (t == 10) {
            Vec3d dir = target != null
                    ? new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ())
                    : Vec3d.fromPolar(0, getYaw());
            dashDir = dir.lengthSquared() < 1.0E-4 ? Vec3d.fromPolar(0, getYaw()) : dir.normalize();
            turnTowards((float) (MathHelper.atan2(dashDir.z, dashDir.x) * 180.0 / Math.PI) - 90.0f, 180f);
            playSound(SoundEvents.ENTITY_IRON_GOLEM_DAMAGE, 1.5f, 0.5f);
        }
        if (t <= 24) {
            Vec3d v = getVelocity();
            setVelocity(dashDir.x * 0.75, v.y, dashDir.z * 0.75);
            sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 0.3, getZ(), 6, 0.8, 0.1, 0.8, 0.02);
            sw.spawnParticles(ParticleTypes.FALLING_NECTAR, getX(), getY() + 3.0, getZ(), 4, 0.8, 0.5, 0.8, 0.0);

            for (LivingEntity e : victimsIn(getBoundingBox().expand(1.3, 0.2, 1.3))) {
                if (!dashHit.add(e.getUuid())) continue;
                hurt(e, attackDamage() * 0.9f);
                knock(e, 2.2, 0.55);
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
                playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 1.0f, 0.8f);
            }
            if (horizontalCollision && t > 12) {
                // nabrak tembok -> langsung masuk fase recovery
                abilityTick = Math.max(abilityTick, 25);
                sw.spawnParticles(HONEY_BITS, getX() + dashDir.x * 1.6, getY() + 2.0, getZ() + dashDir.z * 1.6,
                        40, 0.8, 1.0, 0.8, 0.2);
                playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 1.5f, 0.7f);
            }
        }
    }

    // ---- VOLLEY : Stinger Volley ----
    private void doVolley(LivingEntity target) {
        if (target == null) return;
        Vec3d eye = getEyePos();
        playSound(SoundEvents.ENTITY_ARROW_SHOOT, 2.0f, 0.5f);
        for (int i = 0; i < 3; i++) {
            ArrowEntity arrow = new ArrowEntity(getWorld(), this);
            arrow.setPosition(eye.x, eye.y - 0.4, eye.z);
            double dx = target.getX() - eye.x;
            double dy = target.getBodyY(0.33) - arrow.getY();
            double dz = target.getZ() - eye.z;
            double h = Math.sqrt(dx * dx + dz * dz);
            arrow.setVelocity(dx, dy + h * 0.18, dz, 2.0f, 9.0f);
            arrow.setDamage(5.0);
            arrow.addEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
            arrow.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
            getWorld().spawnEntity(arrow);
        }
    }

    // ---- SUMMON : koloni lebah ----
    private int countTitanBees() {
        return getWorld().getEntitiesByClass(BeeEntity.class, getBoundingBox().expand(40.0),
                b -> b.getCommandTags().contains(BEE_TAG)).size();
    }

    private void summonBees(LivingEntity target, int amount) {
        ServerWorld sw = (ServerWorld) getWorld();
        int n = Math.min(amount, 12 - countTitanBees());
        for (int i = 0; i < n; i++) {
            BeeEntity bee = EntityType.BEE.create(sw);
            if (bee == null) continue;
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double r = 2.5 + this.random.nextDouble() * 1.5;
            bee.refreshPositionAndAngles(getX() + Math.cos(a) * r, getY() + 2.5 + this.random.nextDouble() * 2.0,
                    getZ() + Math.sin(a) * r, this.random.nextFloat() * 360.0f, 0.0f);
            bee.addCommandTag(BEE_TAG);
            if (target != null) {
                bee.setTarget(target);
                bee.setAngryAt(target.getUuid());
                bee.chooseRandomAngerTime();
            }
            sw.spawnEntity(bee);
            sw.spawnParticles(ParticleTypes.FALLING_NECTAR, bee.getX(), bee.getY(), bee.getZ(), 8, 0.3, 0.3, 0.3, 0.0);
        }
    }

    // ---- ROAR : enrage ----
    private void doRoar(int t, LivingEntity target) {
        ServerWorld sw = (ServerWorld) getWorld();
        if (t == 1) {
            playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3.0f, 0.5f);
        }
        if (t == 12) {
            addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 180, 1));
            addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 180, 0));
            playSound(SoundEvents.ENTITY_BEE_LOOP_AGGRESSIVE, 3.0f, 0.4f);
            sw.spawnParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 4.0, getZ(), 1, 0, 0, 0, 0);
            sw.spawnParticles(HONEY_BITS, getX(), getY() + 2.0, getZ(), 120, 2.5, 2.0, 2.5, 0.3);

            for (LivingEntity e : victimsIn(getBoundingBox().expand(10.0, 3.0, 10.0))) {
                knock(e, 1.5, 0.4);
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 160, 0));
            }
        }
        if (t == 30) {
            summonBees(target, 6);
        }
    }

    // ---- HEAL : Royal Jelly ----
    private void doHeal(int t) {
        ServerWorld sw = (ServerWorld) getWorld();
        if (t % 6 == 0) {
            sw.spawnParticles(ParticleTypes.HEART, getX(), getY() + 4.0, getZ(), 3, 0.8, 0.5, 0.8, 0.0);
            sw.spawnParticles(ParticleTypes.FALLING_HONEY, getX(), getY() + 3.0, getZ(), 6, 1.0, 0.5, 1.0, 0.0);
        }
        if (t == 16) {
            heal(getMaxHealth() * 0.12f);
            addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 20 * 20, 2));
            addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 10, 1));
            addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 20 * 6, 1));
            playSound(SoundEvents.BLOCK_HONEY_BLOCK_SLIDE, 2.0f, 0.6f);
        }
    }

    // =====================================================================
    //  Boss bar, NBT, suara, dll.
    // =====================================================================
    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        bossBar.clearPlayers();
        if (!getWorld().isClient()) {
            for (BeeEntity bee : getWorld().getEntitiesByClass(BeeEntity.class, getBoundingBox().expand(48.0),
                    b -> b.getCommandTags().contains(BEE_TAG))) {
                bee.discard();
            }
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Enraged", enraged);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.enraged = nbt.getBoolean("Enraged");
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld().isClient() && this.random.nextInt(8) == 0) {
            getWorld().addParticle(ParticleTypes.FALLING_HONEY, getParticleX(0.9), getRandomBodyY(), getParticleZ(0.9),
                    0.0, 0.0, 0.0);
        }
    }

    @Override
    protected float getActiveEyeHeight(EntityPose pose, EntityDimensions dimensions) {
        return 4.5f;
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BEE_LOOP;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_BEE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_BEE_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.ENTITY_IRON_GOLEM_STEP, 1.2f, 0.7f);
    }

    // =====================================================================
    //  GeckoLib
    // =====================================================================
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // gerakan dasar: idle / jalan / lari
        controllers.add(new AnimationController<>(this, "movement", 6, state -> {
            if (state.isMoving()) {
                return state.setAndContinue(this.isSprinting() ? RUN : WALK);
            }
            return state.setAndContinue(IDLE);
        }));

        // aksi / ability: dipicu dari server lewat triggerAnim("action", nama)
        AnimationController<BeeTitanEntity> action = new AnimationController<>(this, "action", 0, state -> PlayState.STOP);
        for (String name : new String[]{"punch_right", "punch_left", "slam", "spin", "dash", "volley", "summon", "roar", "heal"}) {
            action.triggerableAnim(name, RawAnimation.begin().thenPlay(ANIM_PREFIX + name));
        }
        controllers.add(action);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
