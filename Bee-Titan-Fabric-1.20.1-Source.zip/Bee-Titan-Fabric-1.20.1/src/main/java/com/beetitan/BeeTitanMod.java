package com.beetitan;

import com.beetitan.registry.ModEntities;
import net.fabricmc.api.ModInitializer;

public class BeeTitanMod implements ModInitializer {
    public static final String MOD_ID = "beetitan";

    @Override
    public void onInitialize() {
        ModEntities.register();
    }
}
