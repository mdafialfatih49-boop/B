# Bee Titan (Fabric 1.20.1)

Mod: menambahkan **Bee Titan**, golem lebah raksasa (boss bar, 300 HP) dengan animasi GeckoLib.

## Syarat di game
- Fabric Loader 0.15+, Fabric API, **GeckoLib 4.4.x (Fabric 1.20.1)**

## Cara dapat
- Creative -> tab Spawn Eggs -> *Bee Titan Spawn Egg*, atau `/summon beetitan:bee_titan`

## Ability
Punch (kiri/kanan), Honey Quake (slam), Pollen Whirlwind (spin), Royal Charge (dash),
Stinger Volley (panah racun), Colony Summon (lebah), Roar/Enrage (HP 50%), Royal Jelly (heal HP 35%).
Semua logika ada di `entity/BeeTitanEntity.java`.

## Edit animasi di Blockbench
1. Pasang plugin **GeckoLib Animation Utils** di Blockbench.
2. Buka `assets/beetitan/geo/bee_titan.geo.json`, lalu import `animations/bee_titan.animation.json`.
3. Simpan, build ulang. Nama animasi harus tetap `animation.bee_titan.<nama>`.
Kalau mau pakai model sendiri: pertahankan nama bone (head, body, waist, right_arm, right_forearm, left_arm, left_forearm, right_leg, right_shin, left_leg, left_shin, wing_right, wing_left, stinger, root).

`tools/generate_assets.py` menghasilkan ulang model, tekstur, dan animasi (butuh Pillow).
