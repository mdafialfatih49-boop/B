#!/usr/bin/env python3
"""Generates bee_titan.geo.json, bee_titan.png and bee_titan.animation.json.
Run from project root: python3 tools/generate_assets.py
(Model & animations can then be opened/edited in Blockbench with the GeckoLib plugin.)"""
import json, math, random, os
from PIL import Image

RES = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "beetitan")
TEX = 256

# ---------------------------------------------------------------- model
def mirror(c):  # mirror a cube spec across x=0
    o, s = c["o"], c["s"]
    d = dict(c); d["o"] = [-o[0] - s[0], o[1], o[2]]
    return d

def cube(o, s, kind="gold"): return {"o": o, "s": s, "kind": kind}

bones = []
def bone(name, parent, pivot, cubes=None, rot=None):
    bones.append({"name": name, "parent": parent, "pivot": pivot, "cubes": cubes or [], "rot": rot})

bone("root", None, [0, 0, 0])
bone("waist", "root", [0, 32, 0], [cube([-8, 28, -5], [16, 9, 10], "wax")])
abs_cubes = [cube([-7, 37, -4], [14, 14, 8], "gold")]
for yy in (38, 42, 46):
    abs_cubes += [cube([-5.0, yy, -5], [4, 3, 1], "comb"), cube([1.0, yy, -5], [4, 3, 1], "comb")]
bone("body", "waist", [0, 37, 0], abs_cubes + [
    cube([-11, 50, -6], [22, 16, 12], "gold"),
    cube([-10, 55, -8], [9, 9, 2], "wax"), cube([1, 55, -8], [9, 9, 2], "wax"),   # pecs
])
bone("head", "body", [0, 66, 0], [
    cube([-6, 66, -6], [12, 11, 12], "head"),
    cube([-5, 77, -4], [1, 5, 1], "black"), cube([4, 77, -4], [1, 5, 1], "black"),  # antennae
])
bone("wing_right", "head", [-2, 77, 5], [cube([-11, 77, 4], [9, 1, 11], "wing")], rot=[0, 0, 12])
bone("wing_left", "head", [2, 77, 5], [cube([2, 77, 4], [9, 1, 11], "wing")], rot=[0, 0, -12])
bone("stinger", "body", [7, 64, 6], [cube([6, 63, 6], [2, 2, 9], "stinger"), cube([6.5, 63.5, 15], [1, 1, 3], "stinger")])

# arms (right = -x)
bone("right_arm", "body", [-16, 64, 0], [cube([-22, 61, -6], [12, 10, 12], "wax"), cube([-20, 50, -4], [8, 12, 8], "gold")])
bone("right_forearm", "right_arm", [-16, 50, 0], [cube([-21, 36, -5], [10, 14, 10], "gold"), cube([-22, 26, -6], [12, 10, 12], "wax")])
bone("left_arm", "body", [16, 64, 0], [mirror(cube([-22, 61, -6], [12, 10, 12], "wax")), mirror(cube([-20, 50, -4], [8, 12, 8], "gold"))])
bone("left_forearm", "left_arm", [16, 50, 0], [mirror(cube([-21, 36, -5], [10, 14, 10], "gold")), mirror(cube([-22, 26, -6], [12, 10, 12], "wax"))])

# legs
bone("right_leg", "root", [-6, 30, 0], [cube([-12, 15, -5], [11, 15, 10], "gold")])
bone("right_shin", "right_leg", [-6, 15, 0], [cube([-12, 3, -5], [11, 12, 10], "wax"), cube([-13, 0, -9], [13, 4, 14], "gold")])
bone("left_leg", "root", [6, 30, 0], [mirror(cube([-12, 15, -5], [11, 15, 10], "gold"))])
bone("left_shin", "left_leg", [6, 15, 0], [mirror(cube([-12, 3, -5], [11, 12, 10], "wax")), mirror(cube([-13, 0, -9], [13, 4, 14], "gold"))])

# ---- UV packing (Bedrock box-uv) ----
def box_size(c):
    w, h, d = [math.ceil(v) for v in c["s"]]
    return 2 * (w + d), d + h

placements = []
x = y = shelf_h = 0
for b in bones:
    for c in b["cubes"]:
        bw, bh = box_size(c)
        if x + bw > TEX:
            x = 0; y += shelf_h; shelf_h = 0
        c["uv"] = [x, y]
        placements.append(c)
        x += bw; shelf_h = max(shelf_h, bh)
assert y + shelf_h <= TEX, "atlas overflow"

# ---- texture ----
img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0))
px = img.load()
rnd = random.Random(7)
PAL = {
    "gold":    [(238, 178, 18), (250, 200, 40), (214, 150, 10), (255, 214, 70)],
    "wax":     [(232, 142, 14), (246, 168, 28), (206, 112, 8), (255, 190, 60)],
    "comb":    [(196, 120, 10), (176, 100, 8), (214, 138, 18), (160, 88, 6)],
    "head":    [(244, 170, 30), (252, 192, 48), (222, 140, 18), (255, 208, 70)],
    "black":   [(28, 22, 16), (40, 32, 22), (20, 16, 12), (50, 40, 28)],
    "stinger": [(120, 120, 124), (140, 140, 144), (96, 96, 100), (160, 160, 166)],
    "wing":    [(240, 244, 250), (222, 232, 244), (250, 252, 255), (206, 220, 238)],
}

def faces(c):
    w, h, d = [math.ceil(v) for v in c["s"]]
    u, v = c["uv"]
    return {  # name: (x, y, w, h)   Bedrock box layout
        "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
        "east": (u, v + d, d, h), "north": (u + d, v + d, w, h),
        "west": (u + d + w, v + d, d, h), "south": (u + 2 * d + w, v + d, w, h),
    }

for c in placements:
    pal = PAL[c["kind"]]
    for fname, (fx, fy, fw, fh) in faces(c).items():
        for j in range(fh):
            for i in range(fw):
                r = rnd.random()
                col = pal[0]
                if r > 0.88: col = pal[3]
                elif r > 0.62: col = pal[1]
                elif r < 0.16: col = pal[2]
                if c["kind"] == "wax" and (i + j) % 7 == 0 and rnd.random() > 0.4: col = pal[2]
                if c["kind"] == "comb":  # hexagon-ish grid lines
                    if i % 4 == 0 or j % 3 == 0: col = pal[3] if rnd.random() > .5 else pal[1]
                if c["kind"] == "gold" and fh > 3 and j == fh - 1 and rnd.random() > .5:
                    col = (255, 168, 20)           # honey drip edge
                if c["kind"] == "wing":
                    px[fx + i, fy + j] = col + (170,); continue
                px[fx + i, fy + j] = col + (255,)
    if c["kind"] == "head":
        fx, fy, fw, fh = faces(c)["north"]
        # bee stripes on the sides / back
        for fn in ("east", "west", "south"):
            sx, sy, sw, sh = faces(c)[fn]
            for j in range(sh):
                if j % 6 in (4, 5):
                    for i in range(sw): px[sx + i, sy + j] = (36, 28, 18, 255)
        # eyes (north face is 12x11): big dark eyes with blue glints
        for ex in (1, 7):
            for j in range(3, 9):
                for i in range(ex, ex + 4): px[fx + i, fy + j] = (22, 18, 20, 255)
            px[fx + ex + 1, fy + 4] = (70, 140, 230, 255); px[fx + ex + 2, fy + 4] = (70, 140, 230, 255)
            px[fx + ex + 1, fy + 5] = (40, 90, 190, 255)
        for i in range(4, 8): px[fx + i, fy + 9] = (90, 50, 12, 255)     # mouth
        for i in range(5, 7): px[fx + i, fy + 10] = (90, 50, 12, 255)
os.makedirs(os.path.join(RES, "textures", "entity"), exist_ok=True)
img.save(os.path.join(RES, "textures", "entity", "bee_titan.png"))

# ---- geo json ----
geo_bones = []
for b in bones:
    jb = {"name": b["name"], "pivot": b["pivot"]}
    if b["parent"]: jb["parent"] = b["parent"]
    if b["rot"]: jb["rotation"] = b["rot"]
    if b["cubes"]:
        jb["cubes"] = [{"origin": c["o"], "size": c["s"], "uv": c["uv"]} for c in b["cubes"]]
    geo_bones.append(jb)
geo = {"format_version": "1.12.0", "minecraft:geometry": [{
    "description": {"identifier": "geometry.bee_titan", "texture_width": TEX, "texture_height": TEX,
                    "visible_bounds_width": 10, "visible_bounds_height": 8, "visible_bounds_offset": [0, 2.5, 0]},
    "bones": geo_bones}]}
os.makedirs(os.path.join(RES, "geo"), exist_ok=True)
with open(os.path.join(RES, "geo", "bee_titan.geo.json"), "w") as f: json.dump(geo, f, indent=2)

# ---------------------------------------------------------------- animations
# Konvensi: rotation X + = lengan menggantung ayun ke DEPAN; badan tegak miring ke BELAKANG (X - = condong ke depan).
# rotation Z: lengan kanan keluar = negatif, lengan kiri keluar = positif.
def r(v): return [round(float(a), 3) for a in v]
def kf(d): return {("%.3f" % k).rstrip("0").rstrip("."): r(v) for k, v in sorted(d.items())}
def anim(length, bones_, loop=False):
    out = {"loop": loop, "animation_length": length, "bones": {}}
    for bn, chans in bones_.items():
        out["bones"][bn] = {ch: kf(vals) for ch, vals in chans.items()}
    return out

def cycle(period, steps, fn):
    return {period * i / steps: fn(2 * math.pi * i / steps) for i in range(steps + 1)}

def flap(length, rate, amp):
    n = int(length / rate); d_r = {}; d_l = {}
    for i in range(n + 1):
        s = amp if i % 2 == 0 else -amp
        d_r[i * rate] = [0, 0, s]; d_l[i * rate] = [0, 0, -s]
    return {"wing_right": {"rotation": d_r}, "wing_left": {"rotation": d_l}}

A = {}
# ---- idle (4s loop)
idle = {
    "waist": {"position": cycle(4, 8, lambda p: [0, 0.6 * math.sin(p), 0])},
    "body": {"rotation": cycle(4, 8, lambda p: [-1.2 * math.sin(p), 0, 0])},
    "right_arm": {"rotation": cycle(4, 8, lambda p: [2 * math.sin(p), 0, -3 - 1.5 * math.sin(p)])},
    "left_arm": {"rotation": cycle(4, 8, lambda p: [2 * math.sin(p), 0, 3 + 1.5 * math.sin(p)])},
    "right_forearm": {"rotation": cycle(4, 8, lambda p: [8, 0, 0])},
    "left_forearm": {"rotation": cycle(4, 8, lambda p: [8, 0, 0])},
    "head": {"rotation": cycle(4, 8, lambda p: [1.5 * math.sin(p + 1), 3 * math.sin(p), 0])},
}
idle.update(flap(4, 0.1, 14))
A["idle"] = anim(4, idle, True)

# ---- walk (1.2s) & run (0.7s)
def gait(T, leg, shin, arm, fore, lean, bob, twist, flap_rate):
    steps = 12
    d = {
        "right_leg": {"rotation": cycle(T, steps, lambda p: [leg * math.sin(p), 0, 0])},
        "left_leg": {"rotation": cycle(T, steps, lambda p: [-leg * math.sin(p), 0, 0])},
        "right_shin": {"rotation": cycle(T, steps, lambda p: [-shin * max(0, math.cos(p)), 0, 0])},
        "left_shin": {"rotation": cycle(T, steps, lambda p: [-shin * max(0, -math.cos(p)), 0, 0])},
        "right_arm": {"rotation": cycle(T, steps, lambda p: [-arm * math.sin(p), 0, -4])},
        "left_arm": {"rotation": cycle(T, steps, lambda p: [arm * math.sin(p), 0, 4])},
        "right_forearm": {"rotation": cycle(T, steps, lambda p: [fore + 10 * max(0, -math.sin(p)) * (fore / 20), 0, 0])},
        "left_forearm": {"rotation": cycle(T, steps, lambda p: [fore + 10 * max(0, math.sin(p)) * (fore / 20), 0, 0])},
        "waist": {"position": cycle(T, steps, lambda p: [0, -bob * abs(math.sin(p)), 0]),
                  "rotation": cycle(T, steps, lambda p: [0, twist * math.sin(p), 0])},
        "body": {"rotation": cycle(T, steps, lambda p: [-lean, -twist * 0.8 * math.sin(p), 1.5 * math.sin(p)])},
        "head": {"rotation": cycle(T, steps, lambda p: [lean * 0.6, 0, 0])},
    }
    d.update(flap(T, flap_rate, 20))
    return d
A["walk"] = anim(1.2, gait(1.2, 26, 32, 16, 18, 3, 1.2, 4, 0.06), True)
A["run"] = anim(0.72, gait(0.72, 44, 60, 40, 55, 14, 2.5, 7, 0.04), True)

# ---- punches (1.1s, hit @0.5s)
def punch(side):
    s = -1 if side == "right" else 1
    ar, fo, other = f"{side}_arm", f"{side}_forearm", ("left" if side == "right" else "right")
    return anim(1.1, {
        ar: {"rotation": {0: [0, 0, 0], 0.3: [-55, 0, s * -6], 0.5: [92, 0, 0], 0.7: [92, 0, 0], 1.1: [0, 0, 0]}},
        fo: {"rotation": {0: [8, 0, 0], 0.3: [100, 0, 0], 0.5: [0, 0, 0], 0.7: [0, 0, 0], 1.1: [8, 0, 0]}},
        f"{other}_arm": {"rotation": {0: [0, 0, 0], 0.3: [40, 0, 0], 0.5: [10, 0, 0], 1.1: [0, 0, 0]}},
        f"{other}_forearm": {"rotation": {0: [8, 0, 0], 0.3: [110, 0, 0], 0.5: [90, 0, 0], 1.1: [8, 0, 0]}},
        "body": {"rotation": {0: [0, 0, 0], 0.3: [4, -s * 22, 0], 0.5: [-18, s * 24, 0], 0.7: [-14, s * 18, 0], 1.1: [0, 0, 0]}},
        "waist": {"position": {0: [0, 0, 0], 0.3: [0, -2, 0], 0.5: [0, -3, 0], 1.1: [0, 0, 0]}},
        "head": {"rotation": {0: [0, 0, 0], 0.5: [8, 0, 0], 1.1: [0, 0, 0]}},
    })
A["punch_right"] = punch("right"); A["punch_left"] = punch("left")

# ---- slam (2.0s, impact @1.0s)
A["slam"] = anim(2.0, {
    "right_arm": {"rotation": {0: [0, 0, 0], 0.5: [120, 0, -10], 0.9: [178, 0, -8], 1.0: [60, 0, -4], 1.5: [60, 0, -4], 2.0: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.5: [120, 0, 10], 0.9: [178, 0, 8], 1.0: [60, 0, 4], 1.5: [60, 0, 4], 2.0: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.9: [10, 0, 0], 1.0: [20, 0, 0], 2.0: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.9: [10, 0, 0], 1.0: [20, 0, 0], 2.0: [8, 0, 0]}},
    "body": {"rotation": {0: [0, 0, 0], 0.9: [16, 0, 0], 1.0: [-28, 0, 0], 1.5: [-24, 0, 0], 2.0: [0, 0, 0]}},
    "waist": {"position": {0: [0, 0, 0], 0.9: [0, 1, 0], 1.0: [0, -6, 0], 1.5: [0, -5, 0], 2.0: [0, 0, 0]}},
    "head": {"rotation": {0: [0, 0, 0], 0.9: [-10, 0, 0], 1.0: [14, 0, 0], 2.0: [0, 0, 0]}},
    "right_leg": {"rotation": {0: [0, 0, 0], 1.0: [-14, 0, 0], 1.5: [-12, 0, 0], 2.0: [0, 0, 0]}},
    "left_leg": {"rotation": {0: [0, 0, 0], 1.0: [14, 0, 0], 1.5: [12, 0, 0], 2.0: [0, 0, 0]}},
})

# ---- spin (2.5s): lengan terbentang, putar 2x
A["spin"] = anim(2.5, {
    "root": {"rotation": {0: [0, 0, 0], 0.4: [0, 0, 0], 2.1: [0, -720, 0], 2.5: [0, -720, 0]}},
    "right_arm": {"rotation": {0: [0, 0, 0], 0.4: [0, 0, -88], 2.1: [0, 0, -88], 2.5: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.4: [0, 0, 88], 2.1: [0, 0, 88], 2.5: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.4: [0, 0, 0], 2.1: [0, 0, 0], 2.5: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.4: [0, 0, 0], 2.1: [0, 0, 0], 2.5: [8, 0, 0]}},
    "body": {"rotation": {0: [0, 0, 0], 0.4: [-6, 0, 0], 2.1: [-6, 0, 0], 2.5: [0, 0, 0]}},
    "waist": {"position": {0: [0, 0, 0], 0.4: [0, -3, 0], 2.1: [0, -3, 0], 2.5: [0, 0, 0]}},
    **flap(2.5, 0.05, 25),
})

# ---- dash / royal charge (1.5s): windup .45s, dash .5-1.2, recover
dash_legs = {}
for i in range(15):
    t_ = 0.5 + i * 0.05
    sgn = 1 if i % 2 == 0 else -1
    dash_legs.setdefault("right_leg", {})[t_] = [sgn * 50, 0, 0]
    dash_legs.setdefault("left_leg", {})[t_] = [-sgn * 50, 0, 0]
for k in ("right_leg", "left_leg"):
    dash_legs[k][0] = [0, 0, 0]; dash_legs[k][0.45] = [0, 0, 0]; dash_legs[k][1.5] = [0, 0, 0]
A["dash"] = anim(1.5, {
    **{k: {"rotation": v} for k, v in dash_legs.items()},
    "waist": {"position": {0: [0, 0, 0], 0.4: [0, -8, 0], 0.5: [0, -3, 0], 1.2: [0, -3, 0], 1.5: [0, 0, 0]}},
    "body": {"rotation": {0: [0, 0, 0], 0.4: [8, 0, 0], 0.5: [-34, 0, 0], 1.2: [-34, 0, 0], 1.5: [0, 0, 0]}},
    "right_arm": {"rotation": {0: [0, 0, 0], 0.4: [-70, 0, -10], 0.5: [-80, 0, -6], 1.2: [-80, 0, -6], 1.5: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.4: [-70, 0, 10], 0.5: [-80, 0, 6], 1.2: [-80, 0, 6], 1.5: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.5: [30, 0, 0], 1.2: [30, 0, 0], 1.5: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.5: [30, 0, 0], 1.2: [30, 0, 0], 1.5: [8, 0, 0]}},
    "head": {"rotation": {0: [0, 0, 0], 0.5: [30, 0, 0], 1.2: [30, 0, 0], 1.5: [0, 0, 0]}},
    **flap(1.5, 0.04, 28),
})

# ---- volley (2.0s) tembak @1.0 / 1.3 / 1.6
A["volley"] = anim(2.0, {
    "body": {"rotation": {0: [0, 0, 0], 0.9: [20, 0, 0], 1.0: [-10, 0, 0], 1.1: [14, 0, 0], 1.3: [-10, 0, 0], 1.4: [14, 0, 0], 1.6: [-10, 0, 0], 1.75: [8, 0, 0], 2.0: [0, 0, 0]}},
    "right_arm": {"rotation": {0: [0, 0, 0], 0.8: [75, 0, -22], 1.7: [75, 0, -22], 2.0: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.8: [75, 0, 22], 1.7: [75, 0, 22], 2.0: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.8: [5, 0, 0], 2.0: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.8: [5, 0, 0], 2.0: [8, 0, 0]}},
    "head": {"rotation": {0: [0, 0, 0], 0.9: [-12, 0, 0], 1.0: [8, 0, 0], 2.0: [0, 0, 0]}},
    "stinger": {"position": {0: [0, 0, 0], 0.9: [0, 0, 3], 1.0: [0, 0, -2], 1.3: [0, 0, -2], 1.6: [0, 0, -2], 2.0: [0, 0, 0]},
                "rotation": {0: [0, 0, 0], 0.9: [-25, 0, 0], 1.0: [10, 0, 0], 2.0: [0, 0, 0]}},
    "waist": {"position": {0: [0, 0, 0], 0.9: [0, -2, 0], 1.7: [0, -2, 0], 2.0: [0, 0, 0]}},
})

# ---- summon (2.25s) lengan membentuk V, kepala menengadah
A["summon"] = anim(2.25, {
    "right_arm": {"rotation": {0: [0, 0, 0], 0.7: [0, 0, -150], 1.9: [0, 0, -150], 2.25: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.7: [0, 0, 150], 1.9: [0, 0, 150], 2.25: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.7: [0, 0, 0], 1.9: [0, 0, 0], 2.25: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.7: [0, 0, 0], 1.9: [0, 0, 0], 2.25: [8, 0, 0]}},
    "body": {"rotation": {0: [0, 0, 0], 0.7: [12, 0, 0], 1.9: [12, 0, 0], 2.25: [0, 0, 0]}},
    "head": {"rotation": {0: [0, 0, 0], 0.7: [24, 0, 0], 1.9: [24, 0, 0], 2.25: [0, 0, 0]}},
    **flap(2.25, 0.04, 30),
})

# ---- roar (2.5s): tengadah, dada membusung, getar
shake = {0.0: [0, 0, 0], 0.5: [14, 0, 0]}
sh = {}
for i in range(0, 30):
    sh[0.6 + i * 0.05] = [14, 0, 2.2 if i % 2 == 0 else -2.2]
sh[2.2] = [14, 0, 0]; sh[2.5] = [0, 0, 0]; sh[0] = [0, 0, 0]
A["roar"] = anim(2.5, {
    "body": {"rotation": sh},
    "head": {"rotation": {0: [0, 0, 0], 0.5: [38, 0, 0], 2.2: [38, 0, 0], 2.5: [0, 0, 0]}},
    "right_arm": {"rotation": {0: [0, 0, 0], 0.5: [10, 0, -55], 2.2: [10, 0, -55], 2.5: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.5: [10, 0, 55], 2.2: [10, 0, 55], 2.5: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.5: [50, 0, 0], 2.2: [50, 0, 0], 2.5: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.5: [50, 0, 0], 2.2: [50, 0, 0], 2.5: [8, 0, 0]}},
    "waist": {"position": {0: [0, 0, 0], 0.5: [0, -2, 0], 2.2: [0, -2, 0], 2.5: [0, 0, 0]}},
    **flap(2.5, 0.04, 30),
})

# ---- heal (2.0s): kepalan di dada + denyut skala
A["heal"] = anim(2.0, {
    "right_arm": {"rotation": {0: [0, 0, 0], 0.5: [40, 25, -6], 1.6: [40, 25, -6], 2.0: [0, 0, 0]}},
    "left_arm": {"rotation": {0: [0, 0, 0], 0.5: [40, -25, 6], 1.6: [40, -25, 6], 2.0: [0, 0, 0]}},
    "right_forearm": {"rotation": {0: [8, 0, 0], 0.5: [105, 0, 0], 1.6: [105, 0, 0], 2.0: [8, 0, 0]}},
    "left_forearm": {"rotation": {0: [8, 0, 0], 0.5: [105, 0, 0], 1.6: [105, 0, 0], 2.0: [8, 0, 0]}},
    "body": {"rotation": {0: [0, 0, 0], 0.5: [-8, 0, 0], 1.6: [-8, 0, 0], 2.0: [0, 0, 0]},
             "scale": {0: [1, 1, 1], 0.5: [1.0, 1.0, 1.0], 0.8: [1.07, 1.07, 1.07], 1.1: [1, 1, 1], 1.4: [1.07, 1.07, 1.07], 1.7: [1, 1, 1], 2.0: [1, 1, 1]}},
    "head": {"rotation": {0: [0, 0, 0], 0.5: [14, 0, 0], 1.6: [14, 0, 0], 2.0: [0, 0, 0]}},
    "waist": {"position": {0: [0, 0, 0], 0.5: [0, -3, 0], 1.6: [0, -3, 0], 2.0: [0, 0, 0]}},
})

out = {"format_version": "1.8.0", "animations": {"animation.bee_titan." + k: v for k, v in A.items()}}
os.makedirs(os.path.join(RES, "animations"), exist_ok=True)
with open(os.path.join(RES, "animations", "bee_titan.animation.json"), "w") as f: json.dump(out, f, indent=1)
print("OK:", len(placements), "cubes,", len(A), "animations")
